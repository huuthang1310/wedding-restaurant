<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Wedding_Restaurant
 */

get_header();
?>
			<?php get_template_part( 'module/module-wp/module-25', '404' ); ?> 
			<?php get_template_part( 'module/module-wp/module-26', '404' ); ?>

<?php
get_footer();
