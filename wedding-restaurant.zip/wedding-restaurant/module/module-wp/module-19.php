<div id="wrap-body">
			<section class="page-title">
				<div class="card bg-offset bg-fixed h250" data-image-src="<?php echo get_template_directory_uri()?>/images/kawin-haraffsai-75421.jpg" style="background-image: url(&quot;<?php echo get_template_directory_uri()?>/images/kawin-haraffsai-75421.jpg&quot;);">
					<div class="card-img-overlay">
						<div class="container">
							<h1>reservations</h1>
						</div>
					</div>
				</div>
			</section>
			<section>
				<div class="container">
					<div class="row">
						<div class="col-md-5 text-center cards-pad-40 color-3 cards-title-17">
							<div class="p-40 p-md-0">
								<div class="card border-bottom-2x border-3 p-t-sm-0">
									<i class="fa fa-phone color-yellow m-b-20 main-color"></i>
									<div class="card-body">
										<h5 class="card-title">
											<a href="#">0123 456 789</a>
										</h5>
									</div>
								</div>
								<div class="card border-bottom-2x border-3">
									<i class="fa fa-envelope-o color-yellow m-b-20 main-color"></i>
									<div class="card-body">
										<h5 class="card-title">
											<a href="#">info@gmail.com</a>
										</h5>
									</div>
								</div>
								<div class="card">
									<i class="fa fa-map-signs color-yellow m-b-20 main-color"></i>
									<div class="card-body">
										<h5 class="card-title">
											<a href="#">1418 Riverwood Drive, Suite 3845 Cottonwood</a>
										</h5>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-7">
							<div class="p-30 bg-offset p-xs-0 bg-fixed m-t-sm-40" data-image-src="<?php echo get_template_directory_uri()?>/images/kawin-haraffsai-75421.jpg" style="background-image: url(&quot;<?php echo get_template_directory_uri()?>/images/kawin-haraffsai-75421.jpg&quot;);">
								<div class="p-50 p-md-40 p-xs-0 bg-f">
									<div class="block-title m-b-50">
										<h4 class="card-subtitle">Book a tabe</h4>
										<h2 class="line-default">reservations</h2>
									</div>
									<form class="max-w-600 form-lg">
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Username">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Email">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Phone">
										</div>
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Date">
										</div>
										<div class="form-group">
											<textarea class="form-control" placeholder="Messenge"></textarea>
										</div>
										<div class="text-center">
											<button type="submit" class="btn btn-lg color-f">Reservation</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>