<section class="cards cards-5x2 icns-round-100 color-3 m-0 bg-offset"
    data-image-src="<?php echo get_template_directory_uri()?>/images/food-2863553_960_720.jpg"
    style="background-image: url(&quot;<?php echo get_template_directory_uri()?>/images/food-2863553_960_720.jpg&quot;);">
    <div class="container">
        <div class="block-title">
            <h4 class="card-subtitle">What we do</h4>
            <h2 class="line-default">Our Service</h2>
        </div>
        <div class="row row-15">
            <div class="col-md-4">
                <div class="card box-shadow-sm border-1x">
                    <div class="icn icn-70 border-dotted card-icon">
                        <i class="fa fa-cutlery"></i>
                    </div>
                    <div class="card-body p-t-20">
                        <h3 class="card-title">
                            <a href="http://templatecs.com/demo/template/deliki/html/about.html#">Food &amp;
                                Wine</a>
                        </h3>
                        <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing labore etan dolmagna
                            aliqua uat veniama icingmod</p>
                        <a href="http://templatecs.com/demo/template/deliki/html/about.html#" class="btn">read
                            more</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card main-bg box-shadow-sm color-f">
                    <div class="icn icn-70 border-dotted card-icon">
                        <i class="fa fa-beer"></i>
                    </div>
                    <div class="card-body p-t-20">
                        <h3 class="card-title">
                            <a href="http://templatecs.com/demo/template/deliki/html/about.html#">Beer Club</a>
                        </h3>
                        <p class="card-text color-f">Lorem ipsum dolor sit amet consectetur adipisicing labore
                            edolore magna aliqua uat veniama icimod</p>
                        <a href="http://templatecs.com/demo/template/deliki/html/about.html#" class="btn bg-f">read
                            more</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card box-shadow-sm border-1x">
                    <div class="icn icn-70 border-dotted card-icon">
                        <i class="fa fa-bullhorn"></i>
                    </div>
                    <div class="card-body p-t-20">
                        <h3 class="card-title">
                            <a href="http://templatecs.com/demo/template/deliki/html/about.html#">Event &amp;
                                Wedding</a>
                        </h3>
                        <p class="card-text">Lorem ipsum dolor sit amet consectetur adipisicing labore etan dol
                            magna aliqua uat veniama eiusmod</p>
                        <a href="http://templatecs.com/demo/template/deliki/html/about.html#" class="btn">read
                            more</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>