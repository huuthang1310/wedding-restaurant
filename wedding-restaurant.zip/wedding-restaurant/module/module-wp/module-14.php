<section class="cards statistic bg-offset color-3 cards-title-40"
    data-image-src="<?php echo get_template_directory_uri()?>/images/food-2863553_960_720.jpg"
    style="background-image: url(&quot;<?php echo get_template_directory_uri()?>/images/food-2863553_960_720.jpg&quot;);">
    <div class="container">
        <div class="row row-15">
            <div class="col-sm-6 col-md-3">
                <div class="card">
                    <i class="fa fa-heart main-color m-b-20"></i>
                    <div class="card-body">
                        <h4 class="card-title">1460</h4>
                        <p>Clients Happy</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3">
                <div class="card">
                    <i class="fa fa-cutlery main-color m-b-20"></i>
                    <div class="card-body">
                        <h4 class="card-title">156</h4>
                        <p>food</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3">
                <div class="card">
                    <i class="fa fa-group main-color m-b-20"></i>
                    <div class="card-body">
                        <h4 class="card-title">007</h4>
                        <p>chef</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-md-3">
                <div class="card">
                    <i class="fa fa-bell main-color m-b-20"></i>
                    <div class="card-body">
                        <h4 class="card-title">012</h4>
                        <p>Awards</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>