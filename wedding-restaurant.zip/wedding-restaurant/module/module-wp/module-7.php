<section class="bg-offset" data-image-src="<?php echo get_template_directory_uri();?>/images/jaroslaw-ceborski-23gg5626.jpg" style="background-image: url(&quot;<?php echo get_template_directory_uri() ?>/images/jaroslaw-ceborski-23gg5626.jpg&quot;);">
				<div class="container">
					<div class="block-title">
						<h4 class="card-subtitle">Reservations</h4>
						<h2 class="line-default line-default-f">Book a table</h2>
					</div>
					<form class="m-t-30 form-lg max-w-800 bg-f p-50 p-sm-40 p-xs-30">
						<div class="row row-10">
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" placeholder="User name">
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" placeholder="Phone">
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" placeholder="Email">
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" placeholder="Guest">
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" placeholder="Date">
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" placeholder="Time">
								</div>
							</div>
							<div class="col-sm-12">
								<textarea class="form-control" placeholder="Messenge"></textarea>
							</div>
						</div>
						<div class="text-center">
							<a href="http://templatecs.com/demo/template/deliki/html/home.html#" class="btn btn-lg m-t-30">Book a table</a>
						</div>
					</form>
				</div>
			</section>