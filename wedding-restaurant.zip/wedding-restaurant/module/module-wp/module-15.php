<section class="cards">
    <div class="container">
        <div class="block-title">
            <h4 class="card-subtitle">Our blog</h4>
            <h2 class="line-default">Featured Press</h2>
        </div>
        <div class="row row-15">
            <div class="col-lg-6">
                <div class="card card-inline">
                    <div class="row">
                        <div class="col-sm-6">
                            <img src="<?php echo get_template_directory_uri()?>/images/seafood-2187507_960_720.jpg"
                                alt="image">
                        </div>
                        <div class="col-sm-6">
                            <div class="card-body m-t-xs-30">
                                <div class="card-date-1">
                                    <div class="card-date-inner">
                                        <h6 class="main-color">12</h6>
                                        <p>jannuary</p>
                                    </div>
                                </div>
                                <h3 class="card-title">
                                    <a href="http://templatecs.com/demo/template/deliki/html/about.html#">Mountain
                                        mike’s pizza opens new location in redwood city</a>
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card card-inline m-b-0">
                    <div class="row">
                        <div class="col-sm-6">
                            <img src="<?php echo get_template_directory_uri()?>/images/schnitzel-1817337_960_720.jpg"
                                alt="image">
                        </div>
                        <div class="col-sm-6">
                            <div class="card-body m-t-xs-30">
                                <div class="card-date-1">
                                    <div class="card-date-inner">
                                        <h6 class="main-color">04</h6>
                                        <p>jannuary</p>
                                    </div>
                                </div>
                                <h3 class="card-title">
                                    <a href="http://templatecs.com/demo/template/deliki/html/about.html#">Corner
                                        bakery is now offering fresh, wholesome seasonal specials</a>
                                </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>